vipcoin is a mixed POW/POS cryptocurrency which will be POW for the initial 7 days and pure POS after that.

Website: http://www.yellow-coin.com
Launch Date: 22/04/2014 @ 12:00 GMT


General Specs:

Algorithm: Scrypt POW/POS 
Block Time: 20 seconds
Total Coin: 1,000,000,000 YC
Premine: 0.5% for Dev support, future development and marketing
Mined Block Confirmation: 50
Transaction Confirmation: 3
Port: 16789
Rpc port: 16889 

Block Rewards:

Day 1 (POW): Blocks 1-4320 - 1000 YC 
Day 2-7 (POW): Blocks 4321-30240 - 4,000 YC
Day 8-17 (POS): Nominal Stake Interest: 10% Daily
Day 18- (POS): Nominal Stake Interest: 3.65% Annually